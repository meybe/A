# Line-TCR
Line Bot TCR fixed
. 1 bot utama & 3 bot assist

Requirements:
- 4 Line Clone untuk bot
- 1 Line utama untuk admin/command

Cara Run bot tanpa pc atau di Android :
- (Download Termux & Install)
- pkg install python2
- pip2 install rsa
- pip2 install requests
- pip2 install thrift==0.9.3
- pkg install git
- pkg install nano
- git clone https://github.com/fajrinard/Line-TCR
- cd Line-TCR
- nano line-tcr.py
- (isi admin=["YOUR_MID"], ganti kata YOUR_MID dengan mid akun utama yang ingin dijadikan admin) (biarkan tanda kutipnya)
- (lalu save; ctrl X + Y + enter) (gunakan Hacker's Keyboard, download di playstore)
- python2 line-tcr.py
- (login link/qr ke akun bot)
- Selesai


Thanks to :
- Allah SWT
- merkremont
- AlfathDirk
- team TCR
- dan para mastah/programmer lainnya

#ArdSquadBot
