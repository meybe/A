# -*- coding: utf-8 -*-
# -*- Copyleft @ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻-*-

import json
import requests
import ssl

from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
import TalkService
import LineLoginService
from ttypes import LoginRequest


ssl._create_default_https_context = ssl._create_unverified_context

host = 'https://gd2.line.naver.jp'
LINE_AUTH_QUERY_PATH = '/api/v4p/rs'
LINE_AUTH_QUERY_PATH_FIR        = '/api/v4/TalkService.do'
LINE_CERTIFICATE_PATH = '/Q'
LINE_API_QUERY_PATH_FIR = '/S4'
UA, LA = ("Line/1.17.0\tChrome_OS, \CHROMEOS\t1.17.0\tChrome_OS\t1")
_session    = requests.session()

#Request header dont chages. 
# Callback by LINK.  [no edite cant work] authot by ÑËÔ
# -*- Copyleft @ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻-*-
# LINK QR [LINE OUT TOKEN]
#--------------------------------------------------------------------------------------------

def getJson(url, headers=None):
    if headers is None:
        return json.loads(_session.get(url).text)
    else:
        return json.loads(_session.get(url, headers=headers).text)

def defaultCallback(str):
    print(str)

def createTransport(path=None, update_headers=None, service=None):
    Headers = {
        'User-Agent': UA,
        'X-Line-Application': LA,
        "x-lal": "ja-US_US",
    }
    Headers.update({"x-lpqs" : path})
    if(update_headers is not None):
        Headers.update(update_headers)
    transport = THttpClient.THttpClient(host + path)
    transport.setCustomHeaders(Headers)
    protocol = TCompactProtocol.TCompactProtocol(transport)
    client = service(protocol)
    return client

# LAST PROSSECES.  [PRINT BY ÑËØ]


# Callback by CODE QR.  [no edite cant work] authot by ÑËÔ
# -*- Copyleft @ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻-*-
# QR [Line-py]ー
#--------------------------------------------------------------------------------------------

class LineCallback(object):

    def __init__(self, callback):
        self.callback = callback

    def QrUrl(self, url, showQr=True):
        self.callback("Open this link or scan this QR on your LINE for smartphone in 2 minutes\n" + url)
        if showQr:
            import pyqrcode
            url = pyqrcode.create(url)
            self.callback(url.terminal('green', 'white', 1))

    def default(self, str):
        self.callback(str)

# QR READY [PRINT BY ÑËØ]



#for getRSAKey and getAuthQrCode
client = createTransport(LINE_AUTH_QUERY_PATH_FIR, None, TalkService.Client)

qr = client.getAuthQrcode(keepLoggedIn=1, systemName="LineNeo")
uri = "line://au/q/" + qr.verifier
clb = LineCallback(defaultCallback)
clb.QrUrl(uri, 1)
header = {
        'User-Agent': UA,
        'X-Line-Application': LA,
        "x-lal" : "ja-US_US",
        "x-lpqs" : LINE_AUTH_QUERY_PATH_FIR,
        'X-Line-Access': qr.verifier
}
getAccessKey = getJson(host + LINE_CERTIFICATE_PATH, header)

# client instance for loginZ
client = createTransport(LINE_AUTH_QUERY_PATH, None, LineLoginService.Client)
req = LoginRequest()
req.type = 1
req.verifier = qr.verifier
req.e2eeVersion = 1
res = client.loginZ(req)
client = createTransport(LINE_API_QUERY_PATH_FIR, {'X-Line-Access':res.authToken}, TalkService.Client)
print(res)
print(client.getProfile())


#LAST PROGRESES. 