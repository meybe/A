# LineApi_LineNeo
# Callback by link.  [no edite cant work] authot by ÑËÔ
## -*- Copyleft @ ✍Ŧ€₳M ж Ħ₳ʗҜ฿❂Ŧ✈ And ༺₦Ξ࿋ ₮ΞᏜѪℬ࿋₮༻-*-

just login to Naver LINE with Qr verifier

Please run with Python3  
```
python loginqr.py
```

